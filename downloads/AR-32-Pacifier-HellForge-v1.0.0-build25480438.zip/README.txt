AR-32 Pacifier for HellForge build 25480438

55 rounds with the default magazine, 775 RPM auto, 1200 RPM two-round burst, 130/65 damage, AP 3/3/2/1.

Use HellForge Mods > Add mods, select this ZIP and enable it for the next session. Disable it to remove.
The burst rate has a checked stock-value guard and is applied during data load. No Lua or runtime callbacks.
The offline SDK check does not measure gameplay or FPS. A local raw stat is covered by HellForge's mod sync rules.
