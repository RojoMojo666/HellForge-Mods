DEADLINE — Stock Railgun Blast

Railgun impacts use the stock Scorcher blast at every charge level. The shot uses the stock Railgun projectile, stock direct damage and stock penetration. Railgun and Epoch overcharge protection remain enabled.

Enable only one DEADLINE version. Joined-session impact behavior and stability need a private co-op playtest.
