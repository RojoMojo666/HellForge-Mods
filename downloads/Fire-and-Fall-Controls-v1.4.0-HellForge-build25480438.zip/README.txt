Fire & Fall Controls 1.4.0 for HellForge

Choose fire and fall damage reduction separately. Each control has the
original five choices: Off, 25%, 50%, 75% and 100%. A fresh install defaults
to 100% for both. The Mod Options Menu keeps your applied choices between
sessions, including compatible saved choices from the original mod.

1. On HellForge's Mods page, enable Bingus Shared Loader v18 or newer and
   CowboyBingus Mod Options Menu v1.0.1 or newer with API 1. Leave the
   bundled HellForge editor enabled so the HellForge Lua bridge is loaded.
2. Disable the fixed Fire & Fall mod and any other active mod applying its
   fixed fire or fall values. Add this ZIP and enable it for a new session.
3. Open Esc > Mods > Fire & Fall Controls, choose both values and press
   Apply. Start a fresh mission or respawn if settings aren't reflected yet.

Off removes this mod's change for that control. Hard landings can still
concuss you. Explosions and other damage retain their usual effects.

The controls use the stock Helldiver template. Test in a solo session.
For a quick check, set fire to 75% and fall to 100%, then switch one control
to Off and verify the other stays selected. Check each effect in a separate
fresh spawn. Restart to verify that your applied selections were saved.

To uninstall, set both controls to Off, press Apply and quit. Disable the
add-on before starting a new session.

Target: HellForge 0.4.0-beta, Windows x64, game build 25480438 and SDK 16.
Native settings are checked at startup and on Apply. After setup, there is
no per-frame polling. Gameplay and the real in-game menu still need testing.
