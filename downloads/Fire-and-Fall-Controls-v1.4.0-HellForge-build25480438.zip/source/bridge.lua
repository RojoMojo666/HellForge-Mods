-- Only the installed, published HellForge Lua ABI is used.
local declared = false
return function()
    local have_ffi, ffi = pcall(require, 'ffi')
    if not have_ffi or ffi.os ~= 'Windows' or ffi.arch ~= 'x64' then
        return nil, 'The Windows x64 HellForge Lua bridge is required.'
    end
    if not declared then
        ffi.cdef([[typedef struct {
            uint32_t size, bridge, sdk, ready;
            const char* build;
            const char* logs;
        } RojoFireFallInfo;
        typedef struct {
            uint32_t type, applies;
            double now, base;
            uint64_t now_u64, base_u64;
            const char* holder;
        } RojoFireFallValue;]])
        pcall(ffi.cdef, 'void* GetModuleHandleA(const char* name);')
        pcall(ffi.cdef, 'void* GetProcAddress(void* module, const char* name);')
        declared = true
    end

    local module = ffi.C.GetModuleHandleA('hellforge_modloader.dll')
    if module == nil then return nil, 'The HellForge Lua bridge has not loaded.' end

    local signatures = {
        info = 'int(*)(RojoFireFallInfo*)',
        mod = 'void*(*)(const char*)',
        get = 'int(*)(void*,const char*,uint64_t,uint32_t,uint32_t,RojoFireFallValue*)',
        set = 'int(*)(void*,const char*,uint64_t,uint32_t,uint32_t,double,uint64_t,uint32_t)',
        clear = 'int(*)(void*,const char*,uint64_t,uint32_t,uint32_t)',
        owner = 'uint64_t(*)(const char*,uint32_t,uint32_t*)',
        last = 'const char*(*)(void*)',
        log = 'void(*)(void*,const char*)',
    }
    local sdk = {}
    for name, signature in pairs(signatures) do
        local address = ffi.C.GetProcAddress(module, 'hellforge_lua_' .. name)
        if address == nil then return nil, 'The Lua bridge lacks ' .. name .. '.' end
        sdk[name] = ffi.cast(signature, address)
    end

    local info = ffi.new('RojoFireFallInfo[1]')
    info[0].size = ffi.sizeof('RojoFireFallInfo')
    local function supported()
        return sdk.info(info) == 1 and info[0].bridge >= 3 and info[0].sdk >= 16 and
            info[0].build ~= nil and ffi.string(info[0].build) == '25480438'
    end
    if not supported() then return nil, 'Expected HellForge SDK 16 and game build 25480438.' end
    local mod = sdk.mod('rojo-fire-fall-controls')
    if mod == nil then return nil, 'HellForge refused to register Fire & Fall.' end

    local resource = 0x4d1c334d294dfa97ULL
    local f32, u32 = 5, 3
    local owners = ffi.new('uint32_t[1]')
    local value = ffi.new('RojoFireFallValue[1]')
    local function last()
        local result = sdk.last(mod)
        return result ~= nil and ffi.string(result) or 'HellForge refused the damage edit.'
    end
    local function available()
        return supported() and math.floor(tonumber(info[0].ready) / 2) % 2 == 1
    end
    local function read(control, offset, kind)
        if sdk.get(mod, control.component, resource, offset, kind, value) == 0 then return nil, last() end
        if value[0].type ~= kind then return nil, 'HellForge returned a different field type.' end
        return tonumber(value[0].now), tonumber(value[0].base),
            value[0].holder ~= nil and ffi.string(value[0].holder) or nil
    end
    local function ready(control)
        if not available() then return false, 'Helldiver data is not ready.' end
        if sdk.owner(control.component, control.record, owners) ~= resource or tonumber(owners[0]) ~= 1 then
            return false, 'Helldiver component ownership differs from the matched build.'
        end
        if control.name == 'Fire' then
            for offset = 0x53fc, 0x5414, 8 do
                local element = read(control, offset, u32)
                if element == nil or (element == 1) ~= (offset == 0x5404) then
                    return false, 'The Helldiver fire element was not at its expected position.'
                end
            end
        end
        return true
    end
    return {
        holder = 'lua.rojo-fire-fall-controls',
        available = available,
        ready = ready,
        log = function(message) sdk.log(mod, tostring(message)) end,
        read = function(control, offset) return read(control, offset, f32) end,
        set = function(control, offset, number)
            if sdk.set(mod, control.component, resource, offset, f32, number, 0, 0) == 0 then return false, last() end
            return true
        end,
        clear = function(control, offset)
            if sdk.clear(mod, control.component, resource, offset, f32) == 0 then return false, last() end
            return true
        end,
    }
end
