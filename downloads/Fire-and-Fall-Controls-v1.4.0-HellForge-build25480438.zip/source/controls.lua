local prefix = 'rojo.fall_damage_controls.'
local function control(key, kind, record, fields)
    return {
        id = prefix .. key,
        component = kind == 'Fire' and 'HealthComponentData' or 'AvatarComponentData',
        record = record,
        fields = fields,
        name = kind,
        spec = {
            type = 'choice', mod = 'Fire & Fall Controls', label = kind .. ' damage reduction', default = 5,
            choices = {'Off - 0%', 'Light - 25%', 'Medium - 50%', 'Heavy - 75%', 'No damage - 100%'},
            description = 'Choose the reduction and press Apply. Off restores regular ' .. kind:lower() .. ' damage.',
        },
    }
end

return {
    control('preset', 'Fall', 0, {{0x328, 10}, {0x32c, 300}}),
    control('fire_preset', 'Fire', 76, {{0x5408, 0.5}}),
}
