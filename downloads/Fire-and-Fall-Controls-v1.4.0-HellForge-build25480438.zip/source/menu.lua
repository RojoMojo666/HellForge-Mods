return function(controls, transport)
    local owned, committed, blocked = {}, {}, {}
    local factor = {1, 0.75, 0.5, 0.25, 0}

    local function write(control, field, value)
        local operation = value == nil and transport.clear or transport.set
        local called, result, reason = pcall(operation, control, field[1], value)
        if not called then return false, result end
        return result, reason
    end

    local function change(control, index)
        if blocked[control] then return false, 'A rollback failed. Restart HellForge before retrying.' end
        if type(index) ~= 'number' or factor[index] == nil then return false, 'Invalid preset.' end

        local previous = owned[control]
        local next_factor = index ~= 1 and factor[index] or nil
        if previous == next_factor then return true end

        local ready, reason = transport.ready(control)
        if not ready then return false, reason end

        if next_factor ~= nil then
            for _, field in ipairs(control.fields) do
                local current, base, holder = transport.read(control, field[1])
                local expected = field[2] * (previous or 1)
                if current == nil then return false, base end
                if current ~= expected or base ~= expected or (previous ~= nil and holder ~= transport.holder) then
                    return false, 'Another mod or the editor changed this damage setting. Disable the conflict and retry.'
                end
            end
        end

        for i, field in ipairs(control.fields) do
            local applied, detail = write(control, field, next_factor and field[2] * next_factor)
            if not applied then
                for j = i - 1, 1, -1 do
                    local original = control.fields[j]
                    if not write(control, original, previous and original[2] * previous) then blocked[control] = true end
                end
                if blocked[control] then return false, 'A partial edit could not be restored. Restart HellForge.' end
                return false, tostring(detail or 'HellForge refused the edit.') .. ' Previous settings kept.'
            end
        end
        owned[control] = next_factor
        return true
    end

    local function register(host)
        if type(host) ~= 'table' or host.api ~= 1 or type(host.register_option) ~= 'function' or
           type(host.on_change) ~= 'function' or type(host.get) ~= 'function' or type(host.set) ~= 'function' then
            return false, 'Mod Options Menu API 1 with Apply callbacks is required.'
        end

        local function apply(control)
            local called, index = pcall(host.get, control.id)
            if not called then transport.log(control.name .. ' menu read failed.'); return end
            local success, applied, reason = pcall(change, control, index)
            if success and applied then
                if committed[control] ~= index then
                    committed[control] = index
                    transport.log(control.name .. ' protection applied at ' .. (100 - factor[index] * 100) .. '%.')
                end
            else
                if committed[control] then pcall(host.set, control.id, committed[control]) end
                transport.log(control.name .. ' protection refused. ' .. tostring(success and reason or applied))
            end
        end

        for _, control in ipairs(controls) do
            local accepted, reason = host.register_option(control.id, control.spec)
            if not accepted then return false, reason end
        end

        local active = false
        local function register_callback(control)
            return host.on_change(control.id, function()
                if active then apply(control) end
            end)
        end
        for _, control in ipairs(controls) do
            local accepted, reason = register_callback(control)
            if not accepted then return false, reason end
        end

        active = true
        for _, control in ipairs(controls) do apply(control) end
        return true
    end

    return {register = register}
end
