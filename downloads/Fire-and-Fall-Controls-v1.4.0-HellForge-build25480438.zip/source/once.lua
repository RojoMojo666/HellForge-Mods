return function(env)
    local function wait_until(probe, give_up)
        local previous = rawget(env, 'update')
        if type(previous) ~= 'function' then return false, 'No game update is available for startup.' end

        local active, remaining, until_probe = true, 30, 0
        local wrapper
        local function release()
            active = false
            if rawget(env, 'update') == wrapper then rawset(env, 'update', previous) end
        end
        wrapper = function(...)
            if active then
                if until_probe > 0 then
                    until_probe = until_probe - 1
                else
                    until_probe = 29
                    remaining = remaining - 1
                    local ready, reason = probe()
                    if ready then
                        release()
                    elseif remaining == 0 then
                        release()
                        give_up(reason)
                    end
                end
            end
            return previous(...)
        end
        rawset(env, 'update', wrapper)
        return true
    end

    return {wait_until = wait_until}
end
