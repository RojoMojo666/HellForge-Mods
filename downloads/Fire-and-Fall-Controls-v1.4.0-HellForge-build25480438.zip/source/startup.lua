if not os.getenv('HELLFORGE_MODLOADER') or rawget(_G, 'RojoHellForgeFireFallStarted') then return end
rawset(_G, 'RojoHellForgeFireFallStarted', true)

local timers = make_once(_G)
local transport, started

local function report(message)
    if transport then transport.log(message) else print('Fire & Fall Controls: ' .. tostring(message)) end
end

local function probe()
    local options = rawget(_G, 'ModOptionsMenu')
    if type(options) ~= 'table' then return false, 'Mod Options Menu API 1 is missing.' end
    if not transport then
        local candidate, reason = make_bridge()
        if not candidate then return false, reason end
        transport = candidate
    end
    if not transport.available() then return false, 'Helldiver data is not ready.' end

    local accepted, reason = make_menu(controls, transport).register(options)
    if not accepted then report(reason) end
    return true
end

local function safe_probe()
    local ok, finished, reason = pcall(probe)
    if not ok then report('Startup stopped. ' .. tostring(finished)); return true end
    return finished, reason
end

local function bootstrap()
    if started then return end
    started = true
    if safe_probe() then return end
    local scheduled, why = timers.wait_until(safe_probe, function(reason)
        report('Menu did not start. ' .. tostring(reason or 'Dependencies unavailable.'))
    end)
    if not scheduled then report(why) end
end

local loader = rawget(_G, 'BingusSharedLoader')
if type(loader) == 'table' and type(loader.after_startup) == 'function' then
    local ok, accepted = pcall(loader.after_startup, bootstrap)
    if not ok or accepted == false then bootstrap() end
else
    bootstrap()
end
