HELLSLIDERS v2.2.1 for HellForge

Windows x64. HellForge Lua bridge 3, game build 25480438.

1. In HellForge, enable a compatible Bingus Shared Loader (API 1, v18 or later)
   and CowboyBingus Mod Options Menu (API 1, v1.0.1 or later).
2. Disable the old fixed Oxygenator and any pack that includes fixed slide settings.
3. Replace the earlier HELLSLIDERS ZIP through Mods > Add mods. Enable this version for a new session.
4. Open Esc > Mods > HELLSLIDERS. Select a preset or tune the sliders, then press Apply.
   Switch the master option off and press Apply to remove HELLSLIDERS' own changes.

Tribes Oxygenator is available with De-restricted mode off and keeps its 4.2x
downhill speed. The regular downhill speed slider now goes to 420%.
Presets marked EXP still require De-restricted mode. Switching it off clamps
out-of-range values. Extreme settings can cause slipping or unstable movement.

The original polled the menu and avatar twice per frame. This build checks setup
for a bounded period and then reads or writes only on a committed Apply operation.
It uses the published HellForge Lua bridge. Stock data checks prevent overwriting a
conflicting movement preset. HellForge controls when a setting takes effect, so a
new spawn or mission may be needed. A different component owner leaves edits off.

Offline LuaJIT tests confirmed the preset works with De-restricted mode off,
reopens with the same values, and leaves EXP presets gated. HellForge
recognized the package. This revision still needs an in-game playtest.
