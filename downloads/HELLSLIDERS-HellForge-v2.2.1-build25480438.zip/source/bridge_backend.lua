-- Session-owned HellForge edits. The injected transport only calls public SDK exports.
return function(native, stock)
    local owned = {}
    local blocked = false

    local function apply_value(offset, value)
        if value == nil then return native.clear(offset) end
        return native.set(offset, value)
    end

    local function apply(edits)
        if blocked then return false, 'An edit could not be rolled back. Restart the HellForge session.' end
        local desired, order = {}, {}
        for _, edit in ipairs(edits) do
            local offset, value = edit.offset, edit.value
            if stock[offset] == nil or edit.expect ~= stock[offset] or desired[offset] ~= nil
                or type(value) ~= 'number' or value ~= value or math.abs(value) == math.huge then
                return false, 'Unexpected slide edit. Nothing changed.'
            end
            desired[offset] = value
            order[#order + 1] = offset
        end
        for offset in pairs(owned) do
            if desired[offset] == nil then order[#order + 1] = offset end
        end
        table.sort(order)

        if #order == 0 then return true, 'Stock slide settings.' end
        local ready, reason = native.ready()
        if not ready then return false, reason end

        local changes = {}
        for _, offset in ipairs(order) do
            local old, next_value = owned[offset], desired[offset]
            if next_value == stock[offset] then next_value = nil end
            if old ~= next_value then
                if next_value ~= nil then
                    local current, base, holder = native.read(offset)
                    if current == nil then return false, base end
                    if old == nil then
                        if current ~= stock[offset] or base ~= stock[offset] then
                            return false, ('Slide setting 0x%x differs from stock. Disable other slide edits first.'):format(offset)
                        end
                    elseif current ~= old or base ~= old or holder ~= native.holder then
                        return false, ('Another mod or the editor now owns slide setting 0x%x.'):format(offset)
                    end
                end
                changes[#changes + 1] = {offset = offset, old = old, next_value = next_value}
            end
        end

        local completed = 0
        for _, change in ipairs(changes) do
            local ok, why = apply_value(change.offset, change.next_value)
            if not ok then
                local rollback_ok = true
                for i = completed, 1, -1 do
                    if not apply_value(changes[i].offset, changes[i].old) then rollback_ok = false end
                end
                if not rollback_ok then
                    blocked = true
                    return false, 'A slide edit and its rollback were refused. Restart the HellForge session.'
                end
                return false, tostring(why or 'HellForge refused the slide edit.') .. ' Previous settings kept.'
            end
            completed = completed + 1
        end
        for _, change in ipairs(changes) do owned[change.offset] = change.next_value end
        if next(owned) == nil then return true, 'Removed HELLSLIDERS edits.' end
        return true, 'Slide settings applied. A fresh spawn may be needed.'
    end

    return {apply = apply}
end
