-- Only the published HellForge Lua ABI. No game addresses or memory writes.
local declared = false
return function(expected_owners)
    if not os.getenv('HELLFORGE_MODLOADER') then return nil, 'This module requires a HellForge session.' end
    local have_ffi, ffi = pcall(require, 'ffi')
    if not have_ffi or ffi.os ~= 'Windows' or ffi.arch ~= 'x64' then
        return nil, 'HELLSLIDERS uses the Windows x64 HellForge Lua bridge.'
    end

    if not declared then
        ffi.cdef([[
        typedef struct {
            uint32_t size, bridge, sdk, ready;
            const char* build;
            const char* logs;
        } RojoSlidersInfo;
        typedef struct {
            uint32_t type, applies;
            double now, base;
            uint64_t now_u64, base_u64;
            const char* holder;
        } RojoSlidersValue;
        ]])
        pcall(ffi.cdef, 'void* GetModuleHandleA(const char* name);')
        pcall(ffi.cdef, 'void* GetProcAddress(void* module, const char* name);')
        declared = true
    end
    local module = ffi.C.GetModuleHandleA('hellforge_modloader.dll')
    if module == nil then return nil, 'The HellForge Lua bridge is not loaded.' end

    local definitions = {
        info = 'int(*)(RojoSlidersInfo*)',
        mod = 'void*(*)(const char*)',
        get = 'int(*)(void*,const char*,uint64_t,uint32_t,uint32_t,RojoSlidersValue*)',
        set = 'int(*)(void*,const char*,uint64_t,uint32_t,uint32_t,double,uint64_t,uint32_t)',
        clear = 'int(*)(void*,const char*,uint64_t,uint32_t,uint32_t)',
        owner = 'uint64_t(*)(const char*,uint32_t,uint32_t*)',
        last = 'const char*(*)(void*)',
        log = 'void(*)(void*,const char*)',
    }
    local sdk = {}
    for name, ctype in pairs(definitions) do
        local address = ffi.C.GetProcAddress(module, 'hellforge_lua_' .. name)
        if address == nil then return nil, 'The HellForge bridge lacks ' .. name .. '.' end
        sdk[name] = ffi.cast(ctype, address)
    end

    local info = ffi.new('RojoSlidersInfo[1]')
    info[0].size = ffi.sizeof('RojoSlidersInfo')
    local function check_build()
        return sdk.info(info) == 1 and info[0].bridge >= 3 and info[0].sdk >= 16
            and info[0].build ~= nil and ffi.string(info[0].build) == '25480438'
    end
    if not check_build() then return nil, 'Expected HellForge SDK 16 and game build 25480438.' end
    local handle = sdk.mod('rojo-hellsliders')
    if handle == nil then return nil, 'HellForge refused to register HELLSLIDERS.' end

    local resource = 0x4d1c334d294dfa97ULL
    local component, field_type = 'AvatarComponentData', 5
    local owners = ffi.new('uint32_t[1]')
    local value = ffi.new('RojoSlidersValue[1]')
    local function last()
        local message = sdk.last(handle)
        return message ~= nil and ffi.string(message) or 'HellForge refused the slide field.'
    end
    local function ready()
        if not check_build() then return false, 'HellForge build or bridge changed.' end
        if math.floor(tonumber(info[0].ready) / 2) % 2 ~= 1 then
            return false, 'Helldiver settings are not loaded yet. Apply again once the game has loaded.'
        end
        if sdk.owner(component, 0, owners) ~= resource or tonumber(owners[0]) ~= expected_owners then
            return false, 'The Helldiver settings owner changed. No slide settings were written.'
        end
        return true
    end
    return {
        holder = 'lua.rojo-hellsliders',
        ready = ready,
        log = function(message) sdk.log(handle, tostring(message)) end,
        read = function(offset)
            if sdk.get(handle, component, resource, offset, field_type, value) == 0 then return nil, last() end
            if value[0].type ~= field_type then return nil, 'HellForge returned a different field type.' end
            return tonumber(value[0].now), tonumber(value[0].base),
                value[0].holder ~= nil and ffi.string(value[0].holder) or nil
        end,
        set = function(offset, number)
            local flags = expected_owners > 1 and 1 or 0
            if sdk.set(handle, component, resource, offset, field_type, number, 0, flags) == 0 then return false, last() end
            return true
        end,
        clear = function(offset)
            if sdk.clear(handle, component, resource, offset, field_type) == 0 then return false, last() end
            return true
        end,
    }
end
