-- Mod Options Menu API 1. Collection is deferred until the whole Apply batch has run.
return function(settings, stock, backend, schedule, report)
    local preset_id = settings.prefix .. 'preset'
    local choices = {}
    for i, preset in ipairs(settings.presets) do choices[i] = preset.name end
    local preset_spec = {
        type = 'choice', mod = 'HELLSLIDERS', label = 'General: Preset', default = 1, choices = choices,
        description = 'Select a preset and press APPLY. Manual changes become Custom. De-restricted mode is required for EXP recipes. Changes affect the next spawn when HellForge requires it.',
    }
    local host, active, queued, preset_requested
    local committed, shown_preset, current_edits = nil, nil, {}

    -- Positive finite float32 conversion. Action-slide durations round upward, as in v2.1.2.
    local function round_float32(value, upward)
        if value == 0 then return 0 end
        assert(value > 0 and value < math.huge, 'invalid slider calculation')
        local fraction, exponent = math.frexp(value)
        local significand = fraction * 16777216
        local nearest = math.floor(significand)
        local rest = significand - nearest
        if (upward and rest > 0) or rest > 0.5 or (rest == 0.5 and nearest % 2 ~= 0) then
            nearest = nearest + 1
        end
        return math.ldexp(nearest, exponent - 24)
    end

    local function build_edits(values)
        local edits = {}
        for _, field in ipairs(settings.fields) do
            local expected = assert(stock[field.offset], 'missing stock guard: ' .. field.key)
            local factor = settings.factor(values, field)
            local value = round_float32(expected * factor, field.group == 'duration')
            assert(value <= field.max, 'out of range: ' .. field.key)
            if value ~= expected then
                edits[#edits + 1] = {offset = field.offset, expect = expected, value = value, name = field.key}
            end
        end
        return edits
    end

    local function same_edits(a, b)
        if #a ~= #b then return false end
        for index, x in ipairs(a) do
            if x.offset ~= b[index].offset or x.value ~= b[index].value then return false end
        end
        return true
    end

    local function set_option(id, value)
        local called, ok, reason = pcall(host.set, id, value)
        if not called or not ok then return false, tostring(called and reason or ok) end
        return true
    end

    local function show(values, selected)
        local first_error
        for _, field in ipairs(settings.definitions) do
            if host.get(field.id) ~= values[field.key] then
                local ok, reason = set_option(field.id, values[field.key])
                if not ok then first_error = first_error or reason end
            end
        end
        if host.get(preset_id) ~= selected then
            local ok, reason = set_option(preset_id, selected)
            if not ok then first_error = first_error or reason end
        end
        return not first_error, first_error
    end

    local function apply_backend(edits)
        local called, ok, detail = pcall(backend.apply, edits)
        if not called then return false, tostring(ok) end
        return ok, detail
    end

    local function apply(from_user_preset)
        local values = {}
        for _, field in ipairs(settings.definitions) do values[field.key] = host.get(field.id) end
        local selected = host.get(preset_id)
        if type(selected) ~= 'number' or selected % 1 ~= 0 or not settings.presets[selected] then
            report('Settings unavailable: invalid preset selection.')
            return false
        end
        local valid, invalid_reason = settings.validate(values, true)
        if not valid then report('Settings unavailable: ' .. invalid_reason); return false end

        local desired = settings.restrict(values)
        local notice
        if settings.presets[selected].experimental and not desired.de_restricted then
            selected = shown_preset and settings.matches_preset(desired, shown_preset) and shown_preset or 1
            notice = 'That preset requires De-restricted mode.'
        elseif from_user_preset and selected ~= 1 then
            desired = assert(settings.preset_values(selected, desired))
        end
        if selected ~= 1 and not settings.matches_preset(desired, selected) then selected = 1 end

        local edits = build_edits(desired)
        local mode_revoked = committed and committed.de_restricted and not desired.de_restricted
        local function refused(reason)
            local reverted = false
            if mode_revoked then
                -- Turning off the experimental permission must not silently leave experimental values applied.
                local cleared, detail = apply_backend({})
                if cleared then
                    current_edits = {}
                    desired.enabled = false
                    committed, shown_preset = settings.copy(desired), 1
                    reverted = show(committed, shown_preset)
                else
                    reason = reason .. '; could not clear the active edits: ' .. tostring(detail)
                end
            elseif committed then
                reverted = show(committed, shown_preset)
            end
            report('Settings refused: ' .. tostring(reason) ..
                   (reverted and '. Menu restored.' or '. See the HellForge log.'))
            return false
        end

        local visible, show_error = show(desired, selected)
        if not visible then return refused(show_error) end
        local status
        if not same_edits(edits, current_edits) then
            local ok, detail = apply_backend(edits)
            if not ok then return refused(detail or 'HellForge declined the write batch') end
            current_edits = edits
            status = detail
        end
        committed, shown_preset = settings.copy(desired), selected
        report(notice or status or ('Preset: ' .. choices[selected] .. '.'))
        return true
    end

    local function safely_apply(from_user_preset)
        local ok, result = pcall(apply, from_user_preset)
        if not ok then
            if committed then pcall(show, committed, shown_preset) end
            report('Could not apply settings: ' .. tostring(result))
            return false
        end
        return result
    end

    local function changed(_, id)
        if not active then return end
        if id == preset_id then preset_requested = true end
        if queued then return end
        queued = true
        local scheduled, reason = schedule(function()
            local use_preset = preset_requested
            queued, preset_requested = false, false
            if active then safely_apply(use_preset) end
        end)
        if not scheduled then
            queued, preset_requested = false, false
            report('Could not queue the menu change: ' .. tostring(reason))
        end
    end

    local function register(api)
        if host == api and active then return true end
        if host or type(api) ~= 'table' or api.api ~= 1 or type(api.register_option) ~= 'function' or
           type(api.get) ~= 'function' or type(api.set) ~= 'function' or type(api.on_change) ~= 'function' then
            return false, 'Mod Options Menu API 1 with Apply callbacks is required'
        end
        host = api
        local registrations = {settings.definitions[1], {id = preset_id, spec = preset_spec}}
        for i = 2, #settings.definitions do registrations[#registrations + 1] = settings.definitions[i] end
        for _, row in ipairs(registrations) do
            local ok, reason = host.register_option(row.id, row.spec or row)
            if not ok then return false, reason end
        end
        for _, row in ipairs(registrations) do
            local ok, reason = host.on_change(row.id, changed)
            if not ok then return false, reason end
        end
        active = true
        safely_apply(false) -- Saved settings are read as saved, never replayed as a preset click.
        return true
    end

    return {register = register, preset_id = preset_id, build_edits = build_edits}
end
