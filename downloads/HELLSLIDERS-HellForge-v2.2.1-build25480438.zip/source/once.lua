-- A temporary Lua callback for bounded startup and the end of a menu Apply batch.
-- After the task completes the original update function is restored.
return function(env)
    local function attach(run)
        local previous = rawget(env, 'update')
        if type(previous) ~= 'function' then return false, 'Game update callback unavailable.' end
        local armed, wrapper = true, nil
        local function release()
            armed = false
            if rawget(env, 'update') == wrapper then rawset(env, 'update', previous) end
        end
        wrapper = function(...)
            if armed then
                local ok, reason = pcall(run, release)
                if not ok then
                    release()
                    print('HELLSLIDERS: ' .. tostring(reason))
                end
            end
            return previous(...)
        end
        rawset(env, 'update', wrapper)
        return true
    end

    local function schedule(task)
        return attach(function(release)
            release()
            task()
        end)
    end

    local function wait_until(probe, give_up)
        local remaining, until_probe = 30, 0
        return attach(function(release)
            if until_probe > 0 then until_probe = until_probe - 1 return end
            until_probe = 29
            remaining = remaining - 1
            local finished, reason = probe()
            if finished then
                release()
            elseif remaining == 0 then
                release()
                give_up(reason)
            end
        end)
    end

    return {schedule = schedule, wait_until = wait_until}
end
