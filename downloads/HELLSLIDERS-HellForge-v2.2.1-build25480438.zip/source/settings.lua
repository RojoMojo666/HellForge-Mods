-- Menu, preset and field policy shared by the bridge and movement adapter.
local S={prefix='rojo.slide_enhancement.',definitions={},fields={},presets={}}
local function option(key,kind,label,default,min,max,description,gap)
    local extended=kind=='slider' and key~='slope_enter_angle_percent' and key~='slope_exit_angle_percent'
    if extended then
        description=description..' Normal cap: '..max..'%. Up to 1000% requires De-restricted mode ON.'
    end
    local spec={key=key,id=S.prefix..key,type=kind,mod='HELLSLIDERS',label=label,
        default=default,min=min,max=extended and 1000 or max,normal_max=max,extended=extended,
        step=kind=='slider' and 1 or nil,
        description=description,gap=gap or false}
    S.definitions[#S.definitions+1]=spec
    return spec
end
option('enabled','toggle','General: Enable HELLSLIDERS',true,nil,nil,
    'GENERAL: Enable your applied slide settings. OFF restores the values this mod changed. Select a preset or tune the groups below, then press APPLY.')
option('de_restricted','toggle','General: De-restricted mode (use at your own risk)',false,nil,nil,
    'WARNING: Extreme settings can cause unintentional slipping, strange movement, crashes and other unintended stupid shit. USE AT YOUR OWN RISK. ON unlocks up to 1000% and EXP presets. OFF clamps values to normal limits on APPLY. Slope angles keep their existing limits. No guarantee of stability.')
option('duration_bonus_percent','slider','Duration: All terrain bonus (%)',75,0,420,
    'DURATION: Extra time for crouch slides. 0 = normal, 75 = 1.75x and 420 = 5.2x. Used unless separate terrain values are ON. Collisions and normal interruptions can still end a slide.',true)
option('separate_durations','toggle','Duration: Separate terrain values',false,nil,nil,
    'DURATION: ON uses the three terrain bonuses below instead of All terrain. OFF uses All terrain for every surface. Speed and other groups are independent of duration.')
for _,terrain in ipairs({'flat','uphill','downhill'}) do
    local title=terrain:sub(1,1):upper()..terrain:sub(2)
    option(terrain..'_duration_bonus','slider','Duration: '..title..' bonus (%)',75,0,420,
        'DURATION: Extra crouch-slide time on '..terrain..' terrain. Requires Separate terrain values ON. 0 = normal duration; 420 = 5.2x normal. Press APPLY.')
end
for i,terrain in ipairs({'flat','uphill','downhill'}) do
    local title=terrain:sub(1,1):upper()..terrain:sub(2)
    local normal_speed_cap=terrain=='downhill' and 420 or 300
    option(terrain..'_speed_percent','slider','Speed: '..title..' (% of normal)',100,25,normal_speed_cap,
        'SPEED: Crouch-slide travel speed on '..terrain..' terrain. 100 = unchanged; 150 = 1.5x normal. Combined with longer duration this can greatly increase distance. Adjust to taste in game.',i==1)
end
option('stamina_percent','slider','Stamina: Slide cost (% of normal)',100,0,200,
    'STAMINA: Cost of performing a slide. 100 = unchanged; 50 = half the normal cost; 0 = zero configured slide cost. Does not change sprint drain or stamina recovery.',true)
option('slopes_enabled','toggle','Slopes: Enable slope adjustments',false,nil,nil,
    'SLOPES: Controls automatic sliding on steep terrain, a separate system from crouch slides. ON enables the seven controls below; OFF restores them. Extreme values can cause unintentional slipping without pressing crouch.',true)
local slope_options={
    {'slope_speed_percent','Travel speed',25,300,'How fast the automatic slope slide travels.'},
    {'slope_gravity_percent','Gravity influence',0,300,'How strongly gravity pulls the slope slide downhill. Zero removes this configured gravity contribution, not world gravity.'},
    {'slope_enter_angle_percent','Entry angle',25,150,'Lower values allow automatic sliding on gentler slopes. This scales the original angle; it is not an angle in degrees.'},
    {'slope_exit_angle_percent','Exit angle',25,150,'Lower values keep a slope slide going until terrain becomes flatter. This scales the original angle.'},
    {'slope_enter_delay_percent','Entry delay',0,300,'Time on a sufficiently steep slope before automatic sliding begins. Lower = sooner; 0 = no configured delay.'},
    {'slope_min_duration_percent','Minimum duration',0,420,'Minimum time in the automatic slope-slide state. Higher values can delay regaining ordinary movement.'},
    {'slope_exit_delay_percent','Extreme-slope exit delay',0,300,'Time on a slope too steep for normal movement before the automatic slide ends. Higher = waits longer; not a general slide cooldown.'},
}
for _,s in ipairs(slope_options) do
    option(s[1],'slider','Slopes: '..s[2]..' (%)',100,s[3],s[4],
        'SLOPES: '..s[5]..' 100 = normal. Requires slope adjustments ON.')
end
option('turning_enabled','toggle','Turning: Enable crouch turning adjustments',false,nil,nil,
    'TURNING (EXPERIMENTAL): Changes ordinary crouch turning too. Its effect on steering during a slide is unconfirmed. OFF restores the original crouch turning value.',true)
option('crouch_turn_percent','slider','Turning: Crouch rate (% of normal)',100,25,300,
    'TURNING (EXPERIMENTAL): 100 = unchanged; higher = faster configured crouch rotation. Requires crouch turning adjustments ON. This is not a confirmed slide-steering control.')
option('dirt_percent','slider','Appearance: Dirt buildup (% of normal)',100,0,500,
    'APPEARANCE: Rate of dirt accumulation while sliding. 100 = unchanged; 0 = no new dirt from this sliding field; 400 = four times the rate. Does not clean existing dirt or change traction.',true)

function S.defaults()
    local result={}
    for _,d in ipairs(S.definitions) do result[d.key]=d.default end
    return result
end
function S.copy(values)
    local result={}
    for _,d in ipairs(S.definitions) do result[d.key]=values[d.key] end
    return result
end
function S.limit(values,d)
    return values.de_restricted and d.max or d.normal_max
end
function S.validate(values,absolute_limits)
    if type(values)~='table' then return false,'Settings must be a table' end
    for _,d in ipairs(S.definitions) do
        local v=values[d.key]
        if d.type=='toggle' then
            if type(v)~='boolean' then return false,'Invalid '..d.label end
        elseif type(v)~='number' or v~=v or v<d.min
            or v>(absolute_limits and d.max or S.limit(values,d)) or v%1~=0 then
            return false,'Invalid '..d.label
        end
    end
    return true
end
function S.restrict(values)
    local result=S.copy(values)
    for _,d in ipairs(S.definitions) do
        if d.type=='slider' then result[d.key]=math.min(result[d.key],S.limit(result,d)) end
    end
    return result
end
function S.equal(a,b)
    for _,d in ipairs(S.definitions) do if a[d.key]~=b[d.key] then return false end end
    return true
end
local function preset(name,description,overrides,experimental)
    local values=S.defaults()
    values.duration_bonus_percent=0
    values.de_restricted=experimental or false
    for key,value in pairs(overrides or {}) do
        assert(values[key]~=nil,'Unknown preset key: '..key)
        values[key]=value
    end
    assert(S.validate(values))
    S.presets[#S.presets+1]={name=name,description=description,values=values,experimental=experimental or false}
end
S.presets[1]={name='Custom',description='Your own applied settings.'}
preset('Vanilla','Normal values for every group.',{})
preset('Enhanced','A modest speed boost and longer slides with near-normal stamina cost.',{
    duration_bonus_percent=75,flat_speed_percent=110,downhill_speed_percent=115,stamina_percent=90})
preset('Matrix','Long, slightly slower cinematic slides with easier crouch rotation. No bullet time.',{
    duration_bonus_percent=150,flat_speed_percent=90,uphill_speed_percent=90,downhill_speed_percent=90,
    stamina_percent=50,turning_enabled=true,crouch_turn_percent=150,dirt_percent=50})
preset('Tribes','Fast downhill travel, shorter uphill carry and quicker entry into slope sliding.',{
    duration_bonus_percent=300,separate_durations=true,flat_duration_bonus=300,uphill_duration_bonus=75,downhill_duration_bonus=420,
    flat_speed_percent=170,uphill_speed_percent=115,downhill_speed_percent=220,stamina_percent=35,
    slopes_enabled=true,slope_speed_percent=180,slope_gravity_percent=150,slope_enter_angle_percent=80,
    slope_exit_angle_percent=70,slope_enter_delay_percent=50,slope_min_duration_percent=175,slope_exit_delay_percent=125,
    dirt_percent=75})
preset('Ice Rink','Long glides, gentler downhill pull and slower crouch rotation. Does not change friction.',{
    duration_bonus_percent=420,flat_speed_percent=130,uphill_speed_percent=100,downhill_speed_percent=160,
    stamina_percent=50,slopes_enabled=true,slope_speed_percent=130,slope_gravity_percent=50,
    slope_enter_angle_percent=90,slope_exit_angle_percent=70,slope_enter_delay_percent=75,slope_min_duration_percent=220,
    turning_enabled=true,crouch_turn_percent=75,dirt_percent=0})
preset('Mudskipper','Stronger uphill slides and plenty of dirt for energetic terrain hopping.',{
    duration_bonus_percent=150,separate_durations=true,flat_duration_bonus=150,uphill_duration_bonus=200,downhill_duration_bonus=250,
    flat_speed_percent=125,uphill_speed_percent=150,downhill_speed_percent=140,stamina_percent=75,
    turning_enabled=true,crouch_turn_percent=125,dirt_percent=400})
preset('420 Blaze It','Normal-mode maximum crouch-slide duration with fast travel, eager slopes and zero slide cost.',{
    duration_bonus_percent=420,flat_speed_percent=220,uphill_speed_percent=220,downhill_speed_percent=220,
    stamina_percent=0,slopes_enabled=true,slope_speed_percent=220,slope_gravity_percent=180,
    slope_enter_angle_percent=80,slope_exit_angle_percent=60,slope_enter_delay_percent=25,
    slope_min_duration_percent=200,slope_exit_delay_percent=200,turning_enabled=true,crouch_turn_percent=200,dirt_percent=200})
preset('[EXP] Ludicrous Speed','Extreme travel speed with long slides and low uphill resistance.',{
    duration_bonus_percent=600,flat_speed_percent=600,uphill_speed_percent=350,downhill_speed_percent=800,
    stamina_percent=0,slopes_enabled=true,slope_speed_percent=700,slope_gravity_percent=250,
    slope_enter_angle_percent=80,slope_exit_angle_percent=60,slope_enter_delay_percent=0,
    slope_min_duration_percent=150,slope_exit_delay_percent=125,turning_enabled=true,crouch_turn_percent=250,dirt_percent=300},true)
preset('[EXP] Event Horizon','A ridiculous downhill pull with maximum downhill speed and long carry.',{
    duration_bonus_percent=1000,flat_speed_percent=250,uphill_speed_percent=125,downhill_speed_percent=1000,
    stamina_percent=0,slopes_enabled=true,slope_speed_percent=600,slope_gravity_percent=1000,
    slope_enter_angle_percent=65,slope_exit_angle_percent=50,slope_enter_delay_percent=0,
    slope_min_duration_percent=500,slope_exit_delay_percent=400,turning_enabled=true,crouch_turn_percent=75,dirt_percent=700},true)
preset('[EXP] Soap Dimension','Very long glides with zero slope gravity contribution and lazy crouch rotation.',{
    duration_bonus_percent=1000,flat_speed_percent=350,uphill_speed_percent=200,downhill_speed_percent=500,
    stamina_percent=0,slopes_enabled=true,slope_speed_percent=350,slope_gravity_percent=0,
    slope_enter_angle_percent=70,slope_exit_angle_percent=50,slope_enter_delay_percent=0,
    slope_min_duration_percent=1000,slope_exit_delay_percent=1000,turning_enabled=true,crouch_turn_percent=25,dirt_percent=0},true)
preset('[EXP] Physics Has Left','Maximum duration, speed, slope gravity, crouch turning and dirt; zero slide cost.',{
    duration_bonus_percent=1000,flat_speed_percent=1000,uphill_speed_percent=1000,downhill_speed_percent=1000,
    stamina_percent=0,slopes_enabled=true,slope_speed_percent=1000,slope_gravity_percent=1000,
    slope_enter_angle_percent=80,slope_exit_angle_percent=60,slope_enter_delay_percent=0,
    slope_min_duration_percent=1000,slope_exit_delay_percent=1000,turning_enabled=true,crouch_turn_percent=1000,dirt_percent=1000},true)
preset('Tribes Oxygenator','The fixed Oxygenator values, including 420% downhill speed and normal uphill slide duration.',{
    duration_bonus_percent=50,separate_durations=true,flat_duration_bonus=50,uphill_duration_bonus=0,downhill_duration_bonus=420,
    flat_speed_percent=200,uphill_speed_percent=115,downhill_speed_percent=420,stamina_percent=35,
    slopes_enabled=true,slope_speed_percent=180,slope_gravity_percent=150,slope_enter_angle_percent=80,
    slope_exit_angle_percent=70,slope_enter_delay_percent=50,slope_min_duration_percent=175,slope_exit_delay_percent=125,
    dirt_percent=75})
function S.preset_values(index,current)
    local recipe=S.presets[index]
    if not recipe or not recipe.values then return nil,'No recipe selected' end
    if recipe.experimental and not current.de_restricted then return nil,'De-restricted mode is OFF' end
    local target=S.copy(recipe.values)
    -- A preset cannot provide consent for experimental settings or revoke the
    -- user's checkbox selection. Only the checkbox controls the mode.
    target.de_restricted=current.de_restricted
    return target
end
function S.matches_preset(values,index)
    local target=S.preset_values(index,values)
    return target~=nil and S.equal(values,target)
end

-- Verified prefix layout for the supported build; offsets are relative to the
-- avatar's private settings. Fields after this prefix are never modified.
local function field(key,offset,min,max,max_factor,group,terrain)
    if key~='slope_enter_angle_percent' and key~='slope_exit_angle_percent' then
        max_factor=group=='duration' and 11 or 10
    end
    S.fields[#S.fields+1]={key=key,offset=offset,min=min,max=max,max_factor=max_factor,group=group,terrain=terrain}
end
field('flat_duration_bonus',0xd0,0.01,20,5.2,'duration','flat')
field('uphill_duration_bonus',0xd8,0.01,20,5.2,'duration','uphill')
field('downhill_duration_bonus',0xe0,0.01,20,5.2,'duration','downhill')
field('flat_speed_percent',0xd4,0,50,3)
field('uphill_speed_percent',0xdc,0,50,3)
field('downhill_speed_percent',0xe4,0,50,3)
field('stamina_percent',0x5c,0,1000,2)
field('slope_speed_percent',0xa0,0,50,3,'slopes')
field('slope_gravity_percent',0xa4,0,100,3,'slopes')
field('slope_enter_angle_percent',0x98,0,180,1.5,'slopes')
field('slope_exit_angle_percent',0xac,0,180,1.5,'slopes')
field('slope_enter_delay_percent',0x9c,0,20,3,'slopes')
field('slope_min_duration_percent',0xa8,0,20,4.2,'slopes')
field('slope_exit_delay_percent',0xb0,0,20,3,'slopes')
field('crouch_turn_percent',0x7c,0,100,3,'turning')
field('dirt_percent',0x150,0,1000,5)
function S.factor(values,d)
    if not values.enabled then return 1 end
    if d.group=='slopes' and not values.slopes_enabled then return 1 end
    if d.group=='turning' and not values.turning_enabled then return 1 end
    if d.group=='duration' then
        return 1+(values.separate_durations and values[d.key] or values.duration_bonus_percent)/100
    end
    return values[d.key]/100
end
return S
