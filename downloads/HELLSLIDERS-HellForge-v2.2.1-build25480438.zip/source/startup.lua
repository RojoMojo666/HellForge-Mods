-- Fail closed in Steam and TimeDivers; this mod is for HellForge's Lua bridge.
if not os.getenv('HELLFORGE_MODLOADER') then return end
local timers = make_once(_G)
local transport, started

local function report(message)
    if transport then transport.log(message) else print('HELLSLIDERS: ' .. tostring(message)) end
end

local function start_when_ready()
    local options = rawget(_G, 'ModOptionsMenu')
    if type(options) ~= 'table' then return false, 'Mod Options Menu API 1 is missing.' end
    if not transport then
        local called, candidate, why = pcall(make_native, 1)
        if not called then return false, tostring(candidate) end
        if not candidate then return false, why end
        transport = candidate
    end
    local ready, why = transport.ready()
    if not ready then return false, why end
    local controller = make_menu(settings, stock, make_backend(transport, stock), timers.schedule, report)
    local accepted, reason = controller.register(options)
    if not accepted then report(reason) end
    return true
end

local function probe()
    local ok, finished, reason = pcall(start_when_ready)
    if not ok then report('Initialization stopped: ' .. tostring(finished)) return true end
    return finished, reason
end

local function bootstrap()
    if started then return end
    started = true
    local ready = probe()
    if ready then return end
    local scheduled, reason = timers.wait_until(probe, function(why)
        report('Menu did not start: ' .. tostring(why or 'dependencies unavailable'))
    end)
    if not scheduled then report(reason) end
end

local loader = rawget(_G, 'BingusSharedLoader')
if type(loader) == 'table' and type(loader.after_startup) == 'function' then
    local ok, accepted = pcall(loader.after_startup, bootstrap)
    if not ok or accepted == false then bootstrap() end
else
    bootstrap()
end
