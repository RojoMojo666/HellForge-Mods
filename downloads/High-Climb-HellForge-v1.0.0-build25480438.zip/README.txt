High Climb 1.0.0 for HellForge

The original High Climb preset: 4 m ground climb height and 2 m forward reach.

Open HellForge’s Mods page, choose Add mods and select the ZIP. Enable the
mod and start a new session. Disable it before starting your next session
to remove the changes.

Target: HellForge 0.4.0-beta, build 25480438. The stats loader applies
these edits once at data load if the expected stock fields match. Gameplay
still needs a local test.
