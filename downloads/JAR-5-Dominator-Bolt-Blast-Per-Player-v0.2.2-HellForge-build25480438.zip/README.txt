JAR-5 Dominator Bolt Blast 0.2.2
HellForge game build 25480438

400 RPM automatic, 600 RPM three-shot burst, and Single. Uses the 30-round drum, standard chamber behavior, 325/115 direct damage, AP 4/4/4/2 and the Bolt Pistol blast. This preset can still blast at close range. The 5 m fuse belongs to the separate JAR-5B variant.

Replace the earlier Bolt Blast version in HellForge Mods. Keep only one Dominator preset active. Disable it and start a new session to remove it.

Direct JAR-5 hits have 20 demolition force for cargo-container doors.
