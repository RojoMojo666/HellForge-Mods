Jump Pack Recharge 1.1.0 for HellForge

The LIFT-850 Jump Pack keeps a 7.5-second recharge and adds 20% to its
vertical launch velocity setting. Only the regular Jump Pack is targeted.

In HellForge Mods, replace the previous Jump Pack Recharge release with
this ZIP and start a new session. Test with a freshly equipped LIFT-850.
To remove the preset, disable it before starting the next session.

Target HellForge 0.4.0 beta, game build 25480438. The package and values
passed offline checks. Jump height in-game still needs a playtest.
