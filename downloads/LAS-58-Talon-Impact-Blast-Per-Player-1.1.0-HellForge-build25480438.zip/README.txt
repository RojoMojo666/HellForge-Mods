LAS-58 Talon Impact Blast 1.1.0

The Talon fires immediately and keeps its normal direct hit and ballistics. It uses the stock Loyalist impact blast (1.5 m damage radius) and has 200 heat capacity.

Import this ZIP from HellForge's Mods tab to replace Charged Talon 1.0.0. To remove it, disable or remove Talon Impact Blast in that tab.
