MG-206 Heavy Machine Gun Realistic - Per Player
HellForge 0.4.0 beta | Game build 25480438

The stock MG-206 has 600, 750 and 900 RPM options, revised recoil and
spread, three spare magazines, and three magazines from resupply. It uses
stock ammunition damage. The shared edition carries the handheld-only
50 durable damage preset.

Import the ZIP under HellForge Mods and enable it for your profile.
Use one edition per weapon in the same profile. To remove, disable this
edition and start a new session. The host keeps their own mod setup.

The package passed offline checks. Gameplay in a joined mission is
unverified.
