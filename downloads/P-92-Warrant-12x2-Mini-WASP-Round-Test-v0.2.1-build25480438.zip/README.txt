P-92 Warrant 12/12 Mini-WASP Round Test 0.2.1

This build has two selectable 12-round feeds.

Standard: 140 standard / 60 durable damage; AP 4/4/3/1; 285 m/s; no blast or tracking.

Mini-WASP: based on the stock StA-X3 WASP burst-projectile settings and visual effects, with a smaller-scale profile. It has 140 standard / 110 durable direct damage; AP 4/4/4/3; 300 m/s; 5.5 g; zero drag; gravity 0.15. It adds a 300-damage mini impact blast with 1.25 m inner, 2.5 m outer and 3.5 m shockwave radii. The WASP projectile's penetration slowdown and visual effects are retained. Solo SDK steering remains enabled on this feed.

The Veto donor's reserve settings remain in use.

Requires HellForge 0.5.0-beta (SDK 20), game build 25480438, and synced ownership of the P-69 Veto and P-92 Warrant. Disable the previous Warrant 12/12 test build before enabling this version. Add this ZIP in HellForge, enable it, and start a fresh solo session. Equip P-92L Warrant 12/12 in the secondary slot. The mod status should say two 12-round feed definitions applied.

Hold Reload to open weapon options and use the Magazine selector. Check both loaded counts. Fire three Standard rounds and one Mini-WASP, then switch back and forth. If both started full, look for 9 and 11. Check counts after reload and resupply. Test the Mini-WASP visual, smaller blast and solo steering against a moving target.

This is an offline-built prototype. Menu selection, counts, effect appearance, blast, steering, and animations have no in-game result yet. Disable the ZIP and start a fresh session to remove it.
