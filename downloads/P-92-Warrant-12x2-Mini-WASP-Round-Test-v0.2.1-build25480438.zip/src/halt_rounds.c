#include <string.h>

#include "halt_rounds.h"

enum { STANDARD, MINI_WASP, FEED_COUNT };
enum {
    MAX_RICOCHETS_FIELD = 0xB0,
    WASP_BURST_PROJECTILE = 43,
    WASP_IMPACT_EXPLOSION = 373,
    WASP_PROJECTILE_DAMAGE = 244,
    WASP_EXPLOSION_DAMAGE = 397
};
static const char lawgiver_unit[] = "rojo/warrant_lawgiver/halt12";
static const char lawgiver_secondary_unit[] = "rojo/warrant_lawgiver/secondary12";

_Static_assert(MAX_RICOCHETS_FIELD + sizeof(uint32_t) <= sizeof(HfProjectileSettings), "MaxRicochets is outside the SDK row");

static const char *const projectile_names[FEED_COUNT] = {
    "rojo/warrant_lawgiver/halt12_standard", "rojo/warrant_lawgiver/halt12_mini_wasp"
};
static const float speeds[FEED_COUNT] = {285, 300};
static uint32_t damage_ids[FEED_COUNT];
static uint32_t blast_damage_id;
static uint32_t blast_type;
static uint32_t types[FEED_COUNT];
static uint32_t homing_rule;
static HfRef homing_source;

static bool same(const char *a, const char *b) { return a && b && strcmp(a, b) == 0; }

static bool compatible(const HfApi *api)
{
    return api && api->version >= 20 && api->size >= offsetof(HfApi, explosion_row) + sizeof(api->explosion_row) &&
        api->build_id && same(api->build_id(), "25480438") && api->add_damage && api->add_projectile &&
        api->add_explosion && api->explosion_row && api->set_field;
}

static bool tune_standard_damage(const HfApi *api, HfMod *mod)
{
    const HfSet profile[] = {
        {HF_FIELD(DamageInfo, standard_damage), HF_I32(140)},
        {HF_FIELD(DamageInfo, durable_damage), HF_I32(60)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 0), HF_U32(4)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 1), HF_U32(4)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 2), HF_U32(3)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 3), HF_U32(1)},
    };
    for (size_t i = 0; i < sizeof(profile) / sizeof(profile[0]); ++i)
        if (api->set_field(mod, damage_ids[STANDARD], &profile[i].field, &profile[i].value))
            return false;
    return true;
}
static bool tune_mini_damage(const HfApi *api, HfMod *mod)
{
    const HfSet profile[] = {
        {HF_FIELD(DamageInfo, standard_damage), HF_I32(140)},
        {HF_FIELD(DamageInfo, durable_damage), HF_I32(110)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 0), HF_U32(4)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 1), HF_U32(4)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 2), HF_U32(4)},
        {HF_FIELD_AT(DamageInfo, armor_penetration, 3), HF_U32(3)},
        {HF_FIELD(DamageInfo, demolition), HF_U32(15)},
        {HF_FIELD(DamageInfo, stagger), HF_U32(18)},
    };
    for (size_t i = 0; i < sizeof(profile) / sizeof(profile[0]); ++i)
        if (api->set_field(mod, damage_ids[MINI_WASP], &profile[i].field, &profile[i].value))
            return false;
    return true;
}

bool hf_register_lawgiver_rounds(const HfApi *api, HfMod *mod)
{
    if (!mod || !compatible(api) || damage_ids[STANDARD] || damage_ids[MINI_WASP] || blast_damage_id || blast_type)
        return false;

    const HfDamage standard_damage = {.size = sizeof(standard_damage), .base = 94,
        .name = "rojo/warrant_lawgiver/halt12_warrant_damage"};
    const HfDamage mini_damage = {.size = sizeof(mini_damage), .base = WASP_PROJECTILE_DAMAGE, .scale = 0.625f,
        .name = "rojo/warrant_lawgiver/halt12_mini_wasp_damage"};
    const HfDamage mini_blast_damage = {.size = sizeof(mini_blast_damage), .base = WASP_EXPLOSION_DAMAGE, .scale = 0.5f,
        .name = "rojo/warrant_lawgiver/halt12_mini_wasp_blast_damage"};
    damage_ids[STANDARD] = api->add_damage(mod, &standard_damage);
    damage_ids[MINI_WASP] = api->add_damage(mod, &mini_damage);
    blast_damage_id = api->add_damage(mod, &mini_blast_damage);
    if (damage_ids[STANDARD] < 650 || damage_ids[STANDARD] >= 714 || damage_ids[MINI_WASP] < 650 ||
        damage_ids[MINI_WASP] >= 714 || blast_damage_id < 650 || blast_damage_id >= 714 ||
        !tune_standard_damage(api, mod) || !tune_mini_damage(api, mod))
        return false;

    const HfExplosion blast = {.size = sizeof(blast), .base = WASP_IMPACT_EXPLOSION,
        .name = "rojo/warrant_lawgiver/halt12_mini_wasp_blast", .damage = blast_damage_id,
        .inner_radius = 1.25f, .outer_radius = 2.5f, .shockwave_radius = 3.5f};
    blast_type = api->add_explosion(mod, &blast);
    if (blast_type < 423 || blast_type > 934)
        return false;

    for (size_t i = 0; i < FEED_COUNT; ++i) {
        const bool mini = i == MINI_WASP;
        const HfProjectile projectile = {.size = sizeof(projectile),
            .base = mini ? WASP_BURST_PROJECTILE : HF_PROJECTILE_SMG37_DEFENDER,
            .name = projectile_names[i], .damage = damage_ids[i],
            .visual_from = mini ? WASP_BURST_PROJECTILE : 0,
            .impact_explosion = mini ? blast_type : 0};
        types[i] = api->add_projectile(mod, &projectile);
        if (types[i] < 351 || types[i] >= 415)
            return false;
        const HfSet flight[] = {
            {HF_FIELD(ProjectileSettings, velocity), HF_F32(speeds[i])},
            {HF_FIELD(ProjectileSettings, mass), HF_F32(mini ? 5.5f : 15.0f)},
            {HF_FIELD(ProjectileSettings, drag), HF_F32(0)},
            {HF_FIELD(ProjectileSettings, gravity), HF_F32(mini ? 0.15f : 0.3f)},
        };
        for (size_t field = 0; field < sizeof(flight) / sizeof(flight[0]); ++field)
            if (api->set_field(mod, types[i], &flight[field].field, &flight[field].value))
                return false;
    }
    return types[STANDARD] != types[MINI_WASP];
}

static bool is_owned_copy(const HfApi *api, HfMod *mod, HfRef resource)
{
    const char *owner = api->mod_id(mod);
    for (uint32_t i = 0; ; ++i) {
        HfContent entry = {.size = sizeof(entry)};
        if (!api->content(mod, i, &entry))
            return false;
        if (entry.kind != HF_KIND_ITEM || entry.entity != resource || !same(entry.mod, owner))
            continue;
        if (entry.base == HF_ITEM_SG20_HALT && entry.base_entity == HF_ENTITY_SG20_HALT && same(entry.name, lawgiver_unit))
            return true;
        if (entry.base == HF_ITEM_P69_VETO && entry.base_entity == HF_ENTITY_P69_VETO &&
            same(entry.name, lawgiver_secondary_unit))
            return true;
    }
}

static bool check_damage(const HfApi *api, uint32_t id, int32_t standard, int32_t durable,
    const uint32_t ap[4])
{
    HfDamageInfo row;
    const uintptr_t address = api->damage_row(id);
    return address && !api->read(address, &row, sizeof(row)) && row.id == id &&
        row.standard_damage == standard && row.durable_damage == durable &&
        row.armor_penetration[0] == ap[0] && row.armor_penetration[1] == ap[1] &&
        row.armor_penetration[2] == ap[2] && row.armor_penetration[3] == ap[3] &&
        row.status_1_type == 0 && row.status_2_type == 0 && row.status_3_type == 0 && row.status_4_type == 0;
}

static bool check_ammunition(const HfApi *api, HfMod *mod)
{
    static const uint32_t standard_ap[4] = {4, 4, 3, 1};
    static const uint32_t mini_ap[4] = {4, 4, 4, 3};
    if (damage_ids[STANDARD] < 650 || damage_ids[STANDARD] >= 714 || damage_ids[MINI_WASP] < 650 ||
        damage_ids[MINI_WASP] >= 714 || blast_damage_id < 650 || blast_damage_id >= 714 ||
        types[STANDARD] < 351 || types[STANDARD] >= 415 || types[MINI_WASP] < 351 || types[MINI_WASP] >= 415 ||
        types[STANDARD] == types[MINI_WASP] || blast_type < 423 || blast_type > 934)
        return false;
    if (!check_damage(api, damage_ids[STANDARD], 140, 60, standard_ap) ||
        !check_damage(api, damage_ids[MINI_WASP], 140, 110, mini_ap) ||
        !check_damage(api, blast_damage_id, 300, 300, (const uint32_t[4]){3, 0, 0, 0}))
        return false;

    HfExplosionSettings blast;
    const uintptr_t blast_row = api->explosion_row(blast_type);
    if (!blast_row || api->read(blast_row, &blast, sizeof(blast)) || blast.damage != blast_damage_id ||
        blast.inner_radius != 1.25f || blast.outer_radius != 2.5f || blast.shockwave_radius != 3.5f)
        return false;

    for (size_t i = 0; i < FEED_COUNT; ++i) {
        const bool mini = i == MINI_WASP;
        HfProjectileSettings shot;
        const uintptr_t row = api->projectile_row(types[i]);
        if (!row || api->read(row, &shot, sizeof(shot)) || shot.type != types[i] || shot.damage != damage_ids[i] ||
            shot.pellet_count != 1 || shot.velocity != speeds[i] || shot.mass != (mini ? 5.5f : 15.0f) ||
            shot.drag != 0 || shot.gravity != (mini ? 0.15f : 0.3f) || shot.expiry_explosion ||
            shot.impact_explosion != (mini ? blast_type : 0) ||
            api->write_u32_if(mod, row + MAX_RICOCHETS_FIELD, 1, 0))
            return false;
    }
    return true;
}

bool hf_lawgiver_ready_types(const HfApi *api, HfMod *mod, uint32_t out[2])
{
    if (!mod || !out || !compatible(api) || !api->read || !api->write_u32_if || !api->damage_row ||
        !api->projectile_row || !check_ammunition(api, mod))
        return false;
    memcpy(out, types, sizeof(types));
    return true;
}

bool hf_lawgiver_enable_homing(const HfApi *api, HfMod *mod, HfRef resource)
{
    uint32_t validated_types[FEED_COUNT];
    if (!resource || resource == HF_ENTITY_SG20_HALT || resource == HF_ENTITY_P69_VETO ||
        !hf_lawgiver_ready_types(api, mod, validated_types) || !api->mod_id || !api->content || !api->homing ||
        !is_owned_copy(api, mod, resource))
        return false;
    if (homing_rule)
        return homing_source == resource;

    const uint64_t sources[] = {resource, 0};
    const HfHoming guidance = {.size = sizeof(guidance), .projectile = validated_types[MINI_WASP], .sources = sources,
        .turn_rate = 900, .cone = 30, .range = 35, .arm_distance = 2, .aim_height = 1, .flags = HF_HOMING_NO_RETARGET};
    homing_rule = api->homing(mod, &guidance);
    if (!homing_rule)
        return false;
    homing_source = resource;
    return true;
}

void hf_lawgiver_disable_homing(const HfApi *api, HfMod *mod, HfRef resource)
{
    if (mod && compatible(api) && api->stop_shots && homing_rule && resource == homing_source && api->stop_shots(mod, homing_rule)) {
        homing_rule = 0;
        homing_source = 0;
    }
}


