#ifndef ROJO_LAWGIVER_HALT_ROUNDS_H
#define ROJO_LAWGIVER_HALT_ROUNDS_H

#include <stdbool.h>
#include "hellforge_mod.h"

/* Register the two hit and flight profiles during hellforge_mod_init. */
bool hf_register_lawgiver_rounds(const HfApi *api, HfMod *mod);

/* Read back private ammunition settings and return [Standard, Mini-WASP]. */
bool hf_lawgiver_ready_types(const HfApi *api, HfMod *mod, uint32_t out[2]);

/* Scope the solo SDK homing rule to one of this mod's supported weapons. */
bool hf_lawgiver_enable_homing(const HfApi *api, HfMod *mod, HfRef resource);
void hf_lawgiver_disable_homing(const HfApi *api, HfMod *mod, HfRef resource);

#endif
