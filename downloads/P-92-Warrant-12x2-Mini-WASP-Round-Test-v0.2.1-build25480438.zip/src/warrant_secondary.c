#include <stdint.h>
#include <string.h>

#include "hellforge_mod.h"
#include "halt_rounds.h"

enum { VETO_PROJECTILE = 237, MAGAZINE_FUNCTION = 4, ALTERNATE_ACTOR_OFFSET = 0x248 };
static const char unit[] = "rojo/warrant_lawgiver/secondary12";
static const char* const own_components[] = {
    "WeaponRoundsComponentData", "WeaponDataComponentData", "ProjectileWeaponComponentData", NULL,
};
static HfRef variant;
static uint32_t item;
static int entities_ready;
static int projectiles_ready;

_Static_assert(sizeof(HfProjectileWeapon) == 616, "Projectile weapon layout changed");
_Static_assert(ALTERNATE_ACTOR_OFFSET >= offsetof(HfProjectileWeapon, _unknown_244) &&
    ALTERNATE_ACTOR_OFFSET + sizeof(uint64_t) <= sizeof(HfProjectileWeapon), "Alternate actor guard left its record");

static int owns_secondary(const HfApi* api, HfMod* mod)
{
    const char* owner = api->mod_id(mod);
    if (!owner || !item || api->weapon_entity(item) != variant) return 0;
    for (uint32_t index = 0;; ++index) {
        HfContent entry = {.size = sizeof(entry)};
        if (!api->content(mod, index, &entry)) return 0;
        if (entry.kind == HF_KIND_ITEM && entry.id == item && entry.entity == variant && entry.mod &&
            strcmp(entry.mod, owner) == 0 && entry.base == HF_ITEM_P69_VETO && entry.base_entity == HF_ENTITY_P69_VETO)
            return 1;
    }
}

static void try_configure(const HfApi* api, HfMod* mod)
{
    if (!entities_ready || !projectiles_ready) return;
    if (!owns_secondary(api, mod)) {
        api->set_status(mod, "Idle: Warrant sidearm variant identity did not match");
        return;
    }

    uint32_t rounds_size = 0, weapon_size = 0, fire_size = 0;
    HfWeaponRounds* rounds = (HfWeaponRounds*)api->component_record(own_components[0], variant, &rounds_size);
    HfWeaponData* weapon = (HfWeaponData*)api->component_record(own_components[1], variant, &weapon_size);
    HfProjectileWeapon* fire = (HfProjectileWeapon*)api->component_record(own_components[2], variant, &fire_size);
    if (!rounds || !weapon || !fire || rounds_size != sizeof(*rounds) || weapon_size != sizeof(*weapon) ||
        fire_size != sizeof(*fire)) {
        api->set_status(mod, "Idle: one of the sidearm's private weapon records is unavailable");
        return;
    }

    uint32_t projectiles[2] = {0};
    if (!hf_lawgiver_ready_types(api, mod, projectiles)) {
        api->set_status(mod, "Idle: the Standard and Mini-WASP projectile rows did not pass readback");
        return;
    }

    uint64_t alternate_actor = 0;
    memcpy(&alternate_actor, (const uint8_t*)fire + ALTERNATE_ACTOR_OFFSET, sizeof(alternate_actor));
    if (fire->projectile_entity || fire->weapon_function_projectile_type || alternate_actor ||
        rounds->feed_capacity_1 != 12.0f || rounds->spare_rounds != 90 || rounds->rounds_from_supply != 90 ||
        rounds->starting_rounds != 52 || weapon->weapon_function_right) {
        api->set_status(mod, "Idle: the sidearm's native fire or reserve settings differ from the supported base");
        return;
    }

    const int configured = rounds->primary_projectile == projectiles[0] && rounds->alternate_projectile == projectiles[1] &&
        rounds->feed_capacity_2 == 12.0f && fire->projectile == 0 && weapon->weapon_function_left == MAGAZINE_FUNCTION;
    const int factory = rounds->primary_projectile == VETO_PROJECTILE && rounds->alternate_projectile == 0 &&
        rounds->feed_capacity_2 == 0.0f && fire->projectile == VETO_PROJECTILE && weapon->weapon_function_left == 0;
    if (!configured && !factory) {
        api->set_status(mod, "Idle: the sidearm's feed records differ from the factory or configured pair");
        return;
    }
    if (!hf_lawgiver_enable_homing(api, mod, variant)) {
        api->set_status(mod, "Idle: HellForge refused the solo-only Mini-WASP steering rule");
        return;
    }
    if (factory) {
        /* Halt's native Magazine path has no ordinary or programmable ProjectileWeapon output. */
        rounds->primary_projectile = projectiles[0];
        rounds->alternate_projectile = projectiles[1];
        rounds->feed_capacity_2 = 12.0f;
        fire->projectile = 0;
        weapon->weapon_function_left = MAGAZINE_FUNCTION;
    }
    if (rounds->primary_projectile != projectiles[0] || rounds->alternate_projectile != projectiles[1] ||
        rounds->feed_capacity_2 != 12.0f || fire->projectile || weapon->weapon_function_left != MAGAZINE_FUNCTION) {
        weapon->weapon_function_left = 0;
        fire->projectile = VETO_PROJECTILE;
        rounds->feed_capacity_2 = 0.0f;
        rounds->alternate_projectile = 0;
        rounds->primary_projectile = VETO_PROJECTILE;
        hf_lawgiver_disable_homing(api, mod, variant);
        api->set_status(mod, "Idle: sidearm feed readback failed and factory definitions were restored");
        return;
    }
    api->set_status(mod, "Warrant sidearm: two 12-round feed definitions applied");
}

static void on_ready(HfMod* mod, HfEvent event, void* context)
{
    if (event == HF_EVENT_ENTITIES_READY) entities_ready = 1;
    if (event == HF_EVENT_PROJECTILES_READY) projectiles_ready = 1;
    try_configure(context, mod);
}

HF_MOD_EXPORT int hellforge_mod_init(const HfApi* api, HfMod* mod)
{
    if (!api || !mod || api->version < 20 || api->size < offsetof(HfApi, set_status) + sizeof(api->set_status) ||
        !api->build_id || !api->resource_hash || !api->add_weapon || !api->weapon_entity || !api->component_record ||
        !api->content || !api->mod_id || !api->set_status || !api->on)
        return 1;
    const char* build = api->build_id();
    if (!build || strcmp(build, HF_MAPPINGS_BUILD) != 0) return 1;

    variant = api->resource_hash(unit);
    if (!variant || variant == HF_ENTITY_P69_VETO || variant == HF_ENTITY_P92_WARRANT ||
        (uint32_t)(variant >> 32) == HF_ITEM_P69_VETO || (uint32_t)(variant >> 32) == HF_ITEM_P92_WARRANT)
        return 1;
    if (!hf_register_lawgiver_rounds(api, mod)) return 1;

    const HfWeapon weapon = {
        .size = sizeof(HfWeapon), .base = HF_ITEM_P69_VETO, .unit = unit,
        .designation = "P-92L", .name = "Warrant Lawgiver 12/12",
        .description = "An experimental secondary with Standard and miniaturized WASP feeds.",
        .own_components = own_components,
    };
    item = api->add_weapon(mod, &weapon);
    if (!item || item != (uint32_t)(variant >> 32)) return 1;
    if (api->on(mod, HF_EVENT_ENTITIES_READY, on_ready, (void*)api)) return 1;
    return api->on(mod, HF_EVENT_PROJECTILES_READY, on_ready, (void*)api);
}

