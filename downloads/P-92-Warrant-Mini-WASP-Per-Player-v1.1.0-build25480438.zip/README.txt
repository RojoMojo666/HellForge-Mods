P-92 Warrant Mini-WASP - Per Player 1.1.0

The stock P-92 Warrant fires guided Mini-WASP-style rounds from one 12-round
magazine. The direct hit is 140 standard / 110 durable damage at AP 4/4/4/3.
The original lock-on guides the missile at a configured 300 m/s.

The impact payload uses the stock PLAS-101 Purifier explosion. Its damage is
300 standard / 300 durable at AP 3/3/3/0, with a 3 m outer damage radius.
This version uses the Warrant's original missile and projectile IDs.

Requires HellForge 0.5 beta on game build 25480438 and synced P-92 Warrant
ownership. Import the ZIP with Mods > Add mods, enable it, and equip the P-92
Warrant in a fresh session. Disable the old Warrant 12/12 test if installed.
To uninstall, remove this mod from HellForge and start a fresh session.

HellForge accepts the pack as Per Player. Locked and unlocked impact behavior
and co-op connection stability still need an in-mission check.
