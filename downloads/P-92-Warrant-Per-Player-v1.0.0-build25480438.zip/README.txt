P-92 Warrant - Per Player 1.0.0

Sets the existing P-92 Warrant to a 12-round magazine, 140 standard damage,
60 durable damage, and AP 4/4/3/1 (direct, slight, large, extreme angle).
It keeps the Warrant's original lock-on, projectile, and one magazine feed.

Requires HellForge 0.5 beta on game build 25480438 and synced ownership of
the P-92 Warrant. Other players do not need this stats-only mod installed.

Install through Mods > Add mods and enable P-92 Warrant - Per Player.
Disable the earlier Warrant 12/12 Mini-WASP Round Test if installed.
Start a fresh session and equip the stock P-92 Warrant in your loadout.
To uninstall, remove this ZIP through HellForge and start a fresh session.
