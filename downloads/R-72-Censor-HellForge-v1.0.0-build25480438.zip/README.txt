R-72 Censor
HellForge 0.4.0-beta / game build 25480438 / mod version 1.0.0

Restores the Censor preset: 220 standard damage, 75 durable damage, and penetration 4/4/3/2.

Use Add mods in HellForge, select the ZIP, enable it, then start a new HellForge session.
Disable it and start a new session to remove its changes.
These are startup stats. This package uses no scripts, native mod code or per-frame polling.
Schema-checked offline. The effect and frame rate need in-game confirmation.
