SH-32 Shield Boost 1.0.0 for HellForge

The SH-32 Shield Generator Pack has 300 shield energy. Recharge starts after
60 seconds when damaged and 10 seconds when depleted. The original recharge
rate, shield radius and other shields keep their existing settings.

From HellForge's Mods page, choose Add mods and select this ZIP. Enable SH-32
Shield Boost and start a new session. Test with a freshly equipped SH-32.
To remove it, disable it before starting your next session.

Target: HellForge 0.4.0-beta, game build 25480438. Three named stats edits at
data load. Gameplay timing and energy still need a local test.
