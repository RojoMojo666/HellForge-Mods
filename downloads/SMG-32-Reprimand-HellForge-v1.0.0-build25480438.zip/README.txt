SMG-32 Reprimand for HellForge build 25480438

50 rounds, 800 RPM auto, 1300 RPM three-round burst, AP 4/4/3/1.

Use HellForge Mods > Add mods, select this ZIP and enable it for the next session. Disable it to remove.
The burst rate has a checked stock-value guard and is applied during data load. No Lua or runtime callbacks.
The offline SDK check does not measure gameplay or FPS. A local raw stat is covered by HellForge's mod sync rules.
